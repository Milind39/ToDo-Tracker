🗂️ How to Install ToDo-Tracker

1. Unzip all contents to a folder.
2. Double-click `tracker_setup.exe`
3. Enter your login when prompted.
4. Tracker will auto-run in background on every boot.

✅ DO NOT run files from inside the ZIP without extracting first.
