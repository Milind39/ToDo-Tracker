Download and extract

Double-click tracker.exe

Enter email and password when prompted

Tracker will auto-start next time