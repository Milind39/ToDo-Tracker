ToDo-Tracker Agent

Instructions:
1. Double-click `tracker.exe` to launch the screen time tracker.
2. Login with your registered email and password.
3. The agent will run in background and send screen time to your dashboard.
4. Keep this running to track app usage.
